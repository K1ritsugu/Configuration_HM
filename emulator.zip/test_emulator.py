import unittest
import os
import shutil
import yaml
import csv
import tempfile
from emulator import Emulator

class TestEmulator(unittest.TestCase):
    def setUp(self):
        # Create a temporary config file
        self.config_file = tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.yaml')
        config_data = {
            'user_name': 'testuser',
            'computer_name': 'testmachine',
            'vfs_path': '',
            'log_file_path': ''
        }
        yaml.dump(config_data, self.config_file)
        self.config_file.close()

        # Create a temporary zip file as virtual filesystem
        self.vfs_dir = tempfile.mkdtemp()
        os.makedirs(os.path.join(self.vfs_dir, 'folder1'))
        with open(os.path.join(self.vfs_dir, 'file1.txt'), 'w') as f:
            f.write('Hello World')
        shutil.make_archive('vfs', 'zip', self.vfs_dir)
        self.vfs_zip = 'vfs.zip'

        # Update config with paths
        config_data['vfs_path'] = self.vfs_zip
        config_data['log_file_path'] = 'test_log.csv'
        with open(self.config_file.name, 'w') as f:
            yaml.dump(config_data, f)

        self.emulator = Emulator(self.config_file.name)

    def tearDown(self):
        self.emulator.cleanup()
        os.unlink(self.config_file.name)
        os.remove(self.vfs_zip)
        shutil.rmtree(self.vfs_dir)
        if os.path.exists('test_log.csv'):
            os.remove('test_log.csv')

    def test_ls(self):
        self.emulator.ls()
        # No assertion needed as we just check for errors

    def test_cd(self):
        self.emulator.cd('folder1')
        self.assertIn('folder1', self.emulator.current_dir)

    def test_exit(self):
        with self.assertRaises(SystemExit):
            self.emulator.exit_shell()

    def test_cat(self):
        self.emulator.cat(['file1.txt'])

    def test_tree(self):
        self.emulator.tree()

    def test_uptime(self):
        self.emulator.uptime()

    def test_cd_nonexistent(self):
        self.emulator.cd('nonexistent')
        # Should print error message

    def test_cat_nonexistent(self):
        self.emulator.cat(['nofile.txt'])
        # Should print error message

    def test_ls_in_folder(self):
        self.emulator.cd('folder1')
        self.emulator.ls()
        # Should list contents of folder1

if __name__ == '__main__':
    unittest.main()
